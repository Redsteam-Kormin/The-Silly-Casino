# Let's Go Gambling!
-------------------------
## A Simple Gambling Game In Python!
Use your (totally) reasonable deduction skills to scam the casino!
(Or Get Scammed Yourself...)
---------
# Gamemodes:
-------
# Singleplayer:

    * Blackjack
    Skill-based game, you can also guess your opponents score to win!
    * Dice
    Luck-based: The Game Will Roll lower if you win too much!
    It will roll higher if you lose too much!
    * Slots
    Classic Luck Game. No Strategy, just mindless gambling!
-----------
# Multiplayer Modes:
    2 Player Blackjack:
    * Simple Blackjack with 2 Players (May Not Work Sometimes)
---------

### To - Do List:
-self updating highscore
-more silly quotes
-more options for gambling that change the odds.

#Note: If You Have Quote Suggestions, Tell Dylan Nemeth And They Might Be Added